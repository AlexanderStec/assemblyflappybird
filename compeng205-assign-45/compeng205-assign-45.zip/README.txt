Alexander Stec - Aps2754

This game is a clone of flappy bird, avoid the pipes and ceiling/ground with your flying bird.

P is to pause (try it multiple times as sometimes it's finicky) and space or mouse click is to make the bird fly.